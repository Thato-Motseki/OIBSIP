# OIBSIP Demo Video Script

For the first two seconds of each video, show a static title card containing:
- Full Name
- Track: Java Development
- Task Title

## Task 2
Show the game starting, a low guess, a high guess, a correct guess, score and replay.

## Task 3
Show login, ATM menu, balance, deposit, withdrawal, transfer, transaction history and quit.

## Task 4
Show login, profile setup, MCQ question, four options, navigation, countdown timer, submission confirmation, results and logout.
