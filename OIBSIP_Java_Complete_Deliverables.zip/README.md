# OIBSIP - Java Development

This repository contains Java Development internship tasks for OIBSIP.

## Completed Tasks
- Task 2: Number Guessing Game
- Task 3: ATM Interface
- Task 4: Online Examination System

Each project contains source code and its own README.

## Additional Deliverables
- Project report
- Testing guide
- Demo video script
- LinkedIn post drafts
- Submission checklist
- Git commit guide

Screenshots and video links should be added after actual testing and recording.
