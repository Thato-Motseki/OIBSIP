# OIBSIP Java Development Internship - Project Report

## 1. Introduction
This report documents three Java Development projects: Number Guessing Game, ATM Interface, and Online Examination System.

## 2. Objectives
- Apply Java programming to practical applications.
- Practice object-oriented programming.
- Implement user input and validation.
- Use collections and GUI components.
- Compile, test and manage projects with Git and GitHub.

## 3. Task 2 - Number Guessing Game
A Java console application that generates a number between 1 and 100 and allows the user a limited number of attempts.

Features include random number generation, Too High/Too Low feedback, correct-answer detection, score tracking and replay.

## 4. Task 3 - ATM Interface
A Java console application demonstrating OOP through authentication, balance checking, deposits, withdrawals, transfers and transaction history.

Classes: Main, ATM, Account, Transaction and Bank.

## 5. Task 4 - Online Examination System
A Java Swing application providing login, profile setup, multiple-choice questions, Next/Previous navigation, countdown timing, automatic/manual submission, results and logout.

## 6. Testing
Each application should be tested using normal, boundary and invalid inputs. Evidence should consist of screenshots from actual program runs.

## 7. GitHub
The projects are maintained in the OIBSIP GitHub repository using separate commits for each task.

## 8. Demonstration
Each demo should show the application starting, its major features, and representative test cases.

## 9. Conclusion
The projects provide practical experience with Java console applications, OOP, collections, GUI development and software version control.
