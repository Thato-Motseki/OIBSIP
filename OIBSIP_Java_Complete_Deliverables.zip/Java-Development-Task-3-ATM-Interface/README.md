# Java Task 3 - ATM Interface

A Java console-based ATM interface using object-oriented programming.

## Classes
- `Main` - starts the application
- `ATM` - handles login and menu operations
- `Account` - stores account data and performs transactions
- `Transaction` - records transaction details
- `Bank` - manages accounts

## Features
- User ID and PIN login
- Maximum of 3 incorrect PIN attempts
- Transaction history
- Withdraw
- Deposit
- Transfer
- Balance checking
- Quit option
- `ArrayList` transaction storage
- Encapsulation and switch-case menu

## Test accounts
- User ID: `1001`, PIN: `1234`
- User ID: `1002`, PIN: `4321`

## Run
```bash
javac src/*.java
java -cp src Main
```

## Commit message
`Complete Java Task 3 ATM Interface`
