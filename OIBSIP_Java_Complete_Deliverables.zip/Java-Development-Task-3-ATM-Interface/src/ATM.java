import java.util.Scanner;

public class ATM {
    private final Bank bank;
    private final Scanner scanner;

    public ATM(Bank bank, Scanner scanner) {
        this.bank = bank;
        this.scanner = scanner;
    }

    public void start() {
        Account account = login();

        if (account == null) {
            System.out.println("Access denied.");
            return;
        }

        boolean running = true;

        while (running) {
            System.out.println("\n===== ATM MENU =====");
            System.out.println("1. Transaction History");
            System.out.println("2. Withdraw");
            System.out.println("3. Deposit");
            System.out.println("4. Transfer");
            System.out.println("5. Balance");
            System.out.println("6. Quit");
            System.out.print("Choose an option: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1" -> showHistory(account);
                case "2" -> withdraw(account);
                case "3" -> deposit(account);
                case "4" -> transfer(account);
                case "5" -> System.out.printf("Balance: M%.2f%n", account.getBalance());
                case "6" -> running = false;
                default -> System.out.println("Invalid option.");
            }
        }

        System.out.println("Thank you for using the ATM.");
    }

    private Account login() {
        System.out.print("Enter User ID: ");
        String userId = scanner.nextLine();

        Account account = bank.findAccount(userId);
        if (account == null) {
            return null;
        }

        for (int attempts = 1; attempts <= 3; attempts++) {
            System.out.print("Enter PIN: ");
            String pin = scanner.nextLine();

            if (account.verifyPin(pin)) {
                System.out.println("Login successful.");
                return account;
            }

            System.out.println("Incorrect PIN. Attempts remaining: " + (3 - attempts));
        }

        return null;
    }

    private void showHistory(Account account) {
        System.out.println("\n===== TRANSACTION HISTORY =====");
        if (account.getTransactions().isEmpty()) {
            System.out.println("No transactions available.");
            return;
        }

        for (Transaction transaction : account.getTransactions()) {
            System.out.println(transaction);
        }
    }

    private void withdraw(Account account) {
        System.out.print("Enter withdrawal amount: M");
        double amount = Double.parseDouble(scanner.nextLine());

        if (account.withdraw(amount)) {
            System.out.println("Withdrawal successful.");
        } else {
            System.out.println("Withdrawal failed. Check the amount and available balance.");
        }
    }

    private void deposit(Account account) {
        System.out.print("Enter deposit amount: M");
        double amount = Double.parseDouble(scanner.nextLine());

        if (account.deposit(amount)) {
            System.out.println("Deposit successful.");
        } else {
            System.out.println("Deposit failed. Amount must be greater than zero.");
        }
    }

    private void transfer(Account account) {
        System.out.print("Enter recipient User ID: ");
        String recipientId = scanner.nextLine();

        Account recipient = bank.findAccount(recipientId);

        System.out.print("Enter transfer amount: M");
        double amount = Double.parseDouble(scanner.nextLine());

        if (account.transferTo(recipient, amount)) {
            System.out.println("Transfer successful.");
        } else {
            System.out.println("Transfer failed.");
        }
    }
}
