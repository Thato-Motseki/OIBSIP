import java.util.ArrayList;
import java.util.List;

public class Account {
    private final String userId;
    private String pin;
    private double balance;
    private final List<Transaction> transactions = new ArrayList<>();

    public Account(String userId, String pin, double balance) {
        this.userId = userId;
        this.pin = pin;
        this.balance = balance;
    }

    public String getUserId() {
        return userId;
    }

    public boolean verifyPin(String enteredPin) {
        return pin.equals(enteredPin);
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public double getBalance() {
        return balance;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }

    public boolean withdraw(double amount) {
        if (amount <= 0 || amount > balance) return false;
        balance -= amount;
        transactions.add(new Transaction("Withdrawal", amount, balance));
        return true;
    }

    public boolean deposit(double amount) {
        if (amount <= 0) return false;
        balance += amount;
        transactions.add(new Transaction("Deposit", amount, balance));
        return true;
    }

    public boolean transferTo(Account recipient, double amount) {
        if (recipient == null || recipient == this || amount <= 0 || amount > balance) {
            return false;
        }

        balance -= amount;
        recipient.balance += amount;

        transactions.add(new Transaction("Transfer to " + recipient.userId, amount, balance));
        recipient.transactions.add(new Transaction("Transfer from " + userId, amount, recipient.balance));
        return true;
    }
}
