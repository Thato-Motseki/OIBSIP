import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Bank bank = new Bank();

        bank.addAccount(new Account("1001", "1234", 5000.00));
        bank.addAccount(new Account("1002", "4321", 2500.00));

        Scanner scanner = new Scanner(System.in);
        ATM atm = new ATM(bank, scanner);
        atm.start();

        scanner.close();
    }
}
