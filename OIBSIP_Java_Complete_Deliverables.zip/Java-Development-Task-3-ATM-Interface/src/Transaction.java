public class Transaction {
    private final String type;
    private final double amount;
    private final double balanceAfter;

    public Transaction(String type, double amount, double balanceAfter) {
        this.type = type;
        this.amount = amount;
        this.balanceAfter = balanceAfter;
    }

    @Override
    public String toString() {
        return type + " | Amount: M" + String.format("%.2f", amount)
                + " | Balance: M" + String.format("%.2f", balanceAfter);
    }
}
