# LinkedIn Post Drafts

## Task 2
I completed my OIBSIP Java Development Task 2: Number Guessing Game.

The project uses Java to implement random number generation, limited attempts, feedback, scoring and replay functionality.

#Java #JavaDevelopment #OIBSIP #Programming #GitHub

## Task 3
I completed my OIBSIP Java Development Task 3: ATM Interface.

The project demonstrates object-oriented programming through authentication, deposits, withdrawals, transfers, balance checking and transaction history.

#Java #OIBSIP #JavaDevelopment #OOP #GitHub

## Task 4
I completed my OIBSIP Java Development Task 4: Online Examination System.

The Java Swing application includes login, profile setup, MCQs, navigation, countdown timing, submission and results.

#Java #JavaSwing #OIBSIP #JavaDevelopment #GitHub
