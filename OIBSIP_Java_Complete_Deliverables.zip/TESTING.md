# Testing Guide

## Task 2
Run:
```bash
javac src/NumberGuessingGame.java
java -cp src NumberGuessingGame
```
Test low guess, high guess, correct guess, failed round and replay.

## Task 3
Run:
```bash
javac src/*.java
java -cp src Main
```
Test login, three failed PIN attempts, deposit, withdrawal, transfer, balance and transaction history.

## Task 4
Run:
```bash
javac src/*.java
java -cp src Main
```
Test login, profile, question navigation, timer, manual submission, automatic submission, results and logout.

Do not use fabricated screenshots as testing evidence.
