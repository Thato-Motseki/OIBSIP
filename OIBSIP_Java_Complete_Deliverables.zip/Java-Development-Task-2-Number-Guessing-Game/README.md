# Java Task 2 - Number Guessing Game

A Java console-based number guessing game developed for the OIBSIP Java Development internship.

## Features
- Random number from 1 to 100
- Maximum of 7 attempts
- Too High / Too Low feedback
- Correct-answer detection
- Number revealed when the player loses
- Score tracking
- Play Again option

## Run
```bash
javac src/NumberGuessingGame.java
java -cp src NumberGuessingGame
```

## Commit message
`Complete Java Task 2 Number Guessing Game`
