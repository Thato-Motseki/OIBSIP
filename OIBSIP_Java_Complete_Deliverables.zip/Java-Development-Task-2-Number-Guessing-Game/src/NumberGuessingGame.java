import java.util.Random;
import java.util.Scanner;

public class NumberGuessingGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        int score = 0;
        boolean playAgain = true;

        System.out.println("=================================");
        System.out.println("      NUMBER GUESSING GAME");
        System.out.println("=================================");

        while (playAgain) {
            int target = random.nextInt(100) + 1;
            int maxAttempts = 7;
            boolean guessed = false;

            System.out.println("\nI have selected a number between 1 and 100.");
            System.out.println("You have " + maxAttempts + " attempts.");

            for (int attempt = 1; attempt <= maxAttempts; attempt++) {
                System.out.print("Attempt " + attempt + " - Enter your guess: ");
                int guess = scanner.nextInt();

                if (guess == target) {
                    int points = maxAttempts - attempt + 1;
                    score += points;
                    System.out.println("Correct! You guessed the number.");
                    System.out.println("Points earned: " + points);
                    guessed = true;
                    break;
                } else if (guess < target) {
                    System.out.println("Too Low.");
                } else {
                    System.out.println("Too High.");
                }

                System.out.println("Attempts remaining: " + (maxAttempts - attempt));
            }

            if (!guessed) {
                System.out.println("Game over. The correct number was: " + target);
            }

            System.out.println("Current score: " + score);
            System.out.print("Play again? (yes/no): ");
            playAgain = scanner.next().equalsIgnoreCase("yes");
        }

        System.out.println("\nFinal score: " + score);
        System.out.println("Thank you for playing!");
        scanner.close();
    }
}
