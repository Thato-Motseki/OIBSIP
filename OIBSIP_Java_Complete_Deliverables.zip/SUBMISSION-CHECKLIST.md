# OIBSIP Submission Checklist

## GitHub
- [ ] Repository named `OIBSIP`
- [ ] Task 2 uploaded
- [ ] Task 3 uploaded
- [ ] Task 4 uploaded
- [ ] Source code uploaded
- [ ] README files uploaded
- [ ] Changes committed and pushed

## Testing
- [ ] Task 2 tested
- [ ] Task 3 tested
- [ ] Task 4 tested
- [ ] Actual screenshots captured

## Demonstrations
- [ ] Task 2 demo recorded
- [ ] Task 3 demo recorded
- [ ] Task 4 demo recorded
- [ ] First two seconds contain Full Name, Track and Task Title

## LinkedIn
- [ ] Task 2 post
- [ ] Task 3 post
- [ ] Task 4 post
- [ ] Demo links where required

## Peer Evaluation
- [ ] Watched at least two other interns' demo videos
- [ ] Left substantive comments

## Final Submission
- [ ] GitHub repository link copied
- [ ] Task Submission Form completed
- [ ] Required links submitted
